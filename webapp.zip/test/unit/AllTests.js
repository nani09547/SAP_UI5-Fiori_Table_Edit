sap.ui.define([
	"ETM/Testapp/test/unit/controller/Main.controller"
], function () {
	"use strict";
});